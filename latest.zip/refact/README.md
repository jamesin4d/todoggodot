# First Person with Basic Pickup (physics based) 
# or BOX TOSSINGTON THE FIRST!
Controls
--------
Movement:
- W - forward
- S -  backward
- A -  left
- D -  right
- Left Ctrl (hold/toggle) - Crouch

Pick up:
- E (toggle) - Pickup object
- T + Mouse move (while holding an object) - Rotate object in space
- Left click (while holding an object) - Throw object
- Mouse Scroll - move object closer/further away

